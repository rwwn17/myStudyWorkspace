package entities;

public class Account {
	
	protected String number;
	protected String holderName;
	protected double initialDeposit;
	protected double balance;
	
	
	public Account(String number, String holderName, double initialDeposit) {
		
			this.number = number;
			this.holderName = holderName;
			deposit(initialDeposit);
			this.balance = initialDeposit;
		
	}
	
	public Account(String number, String holderName) {
		
		this.number = number;
		this.holderName = holderName;
	}
	

	
	public String getNumber() {
		return number;
	}


	public String getHolderName() {
		return holderName;
	}

	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}

	public double getInitialDeposit() {
		return initialDeposit;
	}

	public double getBalance() {
		return balance;
	}
	
	public void deposit(double amount) {
		
		if (amount > 0) {
			this.balance += amount;
		} 
		
	}
	
	public void withdraw(double amount) {
		
		if (amount > 0) {
			this.balance -= amount;
		} else if (amount < 0) {
			this.balance += amount;
		} 
	}
	
	public String toString() {
		
		return "Account" + number + ", Holder: " + holderName + ", Balance: $ " + String.format("%.2f \n\n", balance);
	}
	
	
}
