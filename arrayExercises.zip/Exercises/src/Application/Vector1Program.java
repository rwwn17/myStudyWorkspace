package Application;

import java.util.Locale;
import java.util.Scanner;

public class Vector1Program {
	
	public static void main(String[] args) {
		
		Locale.setDefault(Locale.US);
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Welcome to the negative numbers array exercise!\n");
		System.out.println("Input the 'N' size: ");
		int n = sc.nextInt();
		
		while (n <= 0 || n > 10) {
			
			System.out.println("Invalid number. Please, input a number between 1 and 10!");
			System.out.println("Input the 'N' size: ");
			n = sc.nextInt();
			
		}

		int[] numbers = new int[n];
		
		for (int i=0;i<numbers.length;i++) {
			sc.nextLine();
			System.out.println("Input a number: ");
			numbers[i] = sc.nextInt();
			System.out.println();
		}
		
		System.out.println("Números negativos:");
		for (int i=0;i<numbers.length;i++) {
			
			if (numbers[i] < 0) {
				
				System.out.println(numbers[i]);
			} 
		}	
		
			
		
		sc.close();
	}

}
