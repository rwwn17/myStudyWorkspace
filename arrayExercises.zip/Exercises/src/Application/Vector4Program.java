package Application;

import java.util.Locale;
import java.util.Scanner;

public class Vector4Program {
	
	public static void main (String[] args) { 
		
		Locale.setDefault(Locale.US);
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Welcome to the even numbers algorithm!\n");
		System.out.println("How much numbers you will input?");
		int n = sc.nextInt();
		System.out.println("");
		int[] numbers = new int[n];
		String evenNumbers = "";
		int quantityOfEvenNumbers = 0;
		
		for (int i=0; i<numbers.length; i++) {
			sc.nextLine();
			System.out.println("Please, enter a number: ");
			numbers[i] = sc.nextInt();
			System.out.println();
			
			if (numbers[i] % 2 == 0) {
				evenNumbers += numbers[i] + (" ");
				quantityOfEvenNumbers += 1;
			}
			
			
		}
		if (quantityOfEvenNumbers > 0) {
			System.out.printf("Even numbers: %s", evenNumbers);
			System.out.println();
			System.out.printf("Quantity of even numbers: %s", quantityOfEvenNumbers);
		} else {
			System.out.println("Sorry, but you did not entered an even number!");
		}
		
		sc.close();
	}

}
