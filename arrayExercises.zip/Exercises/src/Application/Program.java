package Application;

import java.util.Locale;
import java.util.Scanner;
import Entities.Product;

public class Program {
	
	public static void main (String[] args) {
		
		Locale.setDefault(Locale.US);		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Welcome to the example about arrays!\n");
		System.out.println("Input the 'N' size: ");
		int n = sc.nextInt();
		Product[] products = new Product[n];
		
		for (int i=0; i<products.length; i++) {
			
			sc.nextLine();
			
			System.out.println("Informe o nome do produto " + (i + 1) + ":");
			String name = sc.nextLine();
			
			System.out.println("Informe o preço do produto " + (i + 1)  + ": ");
			double price = sc.nextDouble();		
			
			products[i] = new Product(name,price);
			System.out.println();
			
			
		}
		
		for (int i=0; i<products.length; i++) {
			System.out.println("Object " + (i + 1) + "- " + products[i].toString());
			System.out.println();
			
		}
		
		double sum = 0.00;
		for (int i=0; i<products.length; i++) {
			
			sum += products[i].getPrice();
		}
		
		double avg = sum / products.length;
		
		System.out.printf("The average price is: $ %.2f", avg);
		System.out.println();
		
		
		sc.close();
		
	}

}
