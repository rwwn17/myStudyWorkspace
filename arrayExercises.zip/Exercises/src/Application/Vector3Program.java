package Application;

import java.util.Locale;
import java.util.Scanner;
import Entities.People;

public class Vector3Program {
	
	public static void main(String[] args) {
		
		Locale.setDefault(Locale.US);
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Welcome to the People Vector Exercise!\n");
		System.out.println("Please, input the number of people that you want to register:");
		int n = sc.nextInt();
		System.out.println();
		
		People[] person = new People[n];
		double sum = 0;
		double youngers = 0;
		String youngersnames = "";
		
		for (int i=0;i<person.length;i++) {
			sc.nextLine();
			System.out.println("Input the name of the person " + (i + 1) + ":");
			String name = sc.next();
			
			System.out.println("Input the age of the person " + (i + 1) + ":");
			int age = sc.nextInt();
			
			System.out.println("Input the height of the person " + (i + 1) + ":");
			double height = sc.nextDouble();
			
			person[i] = new People(name,age,height);
			sum += person[i].getHeight();
			
			System.out.println();
			
			if (person[i].getAge() < 16) {
				youngers += 1;
				youngersnames += person[i].getName() + (" \n");
			} 
			
		}
				
		System.out.printf("The medium height is: %.2f", (sum / person.length));
		System.out.println();
		
		if (youngers > 0) {
			System.out.printf("The percentual of people with less than 16 years old is: %.1f%%",((youngers / person.length) * 100));
			System.out.println();
			System.out.println("They are: \n" + youngersnames);
		}
		
		
		sc.close();
	}

}
