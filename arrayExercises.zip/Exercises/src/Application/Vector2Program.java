package Application;

import java.util.Locale;
import java.util.Scanner;

public class Vector2Program {
	
	public static void main(String[] args) {
		
		Locale.setDefault(Locale.US);
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Welcome to the sum and average array exercise!\n");
		System.out.println("Input the 'N' size:");
		int n = sc.nextInt();
		double[] valores = new double[n]; 
		double sum = 0;
		
		for(int i=0; i<n; i++) {
			sc.nextLine();
			System.out.println("Input a number:");
			valores[i] = sc.nextDouble();
			sum += valores[i];
			
		}
		
		System.out.println();
		System.out.print("Values: ");
		for(int i=0; i<n; i++) {
			
			System.out.print(valores[i] + " ");
		}
		
		System.out.println();
		System.out.printf("Sum: %.2f", sum);
		
		System.out.println();
		double avg = sum / n;
		System.out.printf("Average: %.2f", avg);
		
		sc.close();
	}
	

}
